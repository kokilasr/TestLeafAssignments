package steps;


import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;

import java.io.File;
import java.util.Map;
import java.util.Map.Entry;

import io.cucumber.java.en.*;
import io.qameta.allure.Step;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;

import hooks.SetUp;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class JiraManagementMatschie extends Common{
	
	

	public static RequestSpecification input;
	public static Response response;
	public static String key;
	
	@Given("Set the Endpoint")
	public void setEndpoint() {
	RestAssured.baseURI="https://kokilajira.atlassian.net/rest/api/2/issue/";
	}
	
	@And("Set the Auth")
	public void setAuth() {
	
		RestAssured.authentication=RestAssured.preemptive().basic("kokila.shree@gmail.com", "ATATT3xFfGF0E9tJabu2qrkomuU_e9n4mYwnRJAzxuCRzauhMZ6kb5bWV-j_QFlaoeeNl2RX0avlzuJq437wb1ujZ8B9exNmV97hnCP2YKUZFr4By3-bna1qGBwRYfxYAu_-0u57Ini5bX4BnLMU81Cl578Jd2yuOGvRXi0X3lPju42TgFoMx9M=DF1B4E12");
	}
	
	@When("Create JIRA task {string}")
	//@Step("Create JIRA Task {fileName}")
	public void createIncidentFile(String fileName) {
		File file=new File("./src/test/resources/"+fileName);
		input=RestAssured.given()
				.contentType("application/json").body(file);
		  response=input.post();
		  key = response.jsonPath().get("key");
	}
	
	@When("Update Jira task {string}")
	public void updateIncident(String updateFile) {
		File updateFileName =new File("./src/test/resources/"+updateFile);
		input=RestAssured.given()
		.contentType("application/json").body(updateFileName);
			    response=input.put(key);
		
	}
	@When("delete Jira task")
	public void deleteIncident() {
		
		response=RestAssured.delete(key);
	}
	
	@Then("validate status code as {int}")
	    public void validateResponseCode(int statusCode) {
		
		response.then().assertThat()
		.statusCode(statusCode);
	    	
	    }
	
}


