package week3AssignmentJIRAChaining;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class BaseClass {

	public static RequestSpecification input;
	public static Response response;
	public static String key;
	
	@BeforeMethod
	public void PreRequisiteSetup()
	{
		//Endpoint
		RestAssured.baseURI = "https://kokilajira.atlassian.net/rest/api/2/issue/";

		//Authentication
		RestAssured.authentication = RestAssured.preemptive().basic("kokila.shree@gmail.com","ATATT3xFfGF0E9tJabu2qrkomuU_e9n4mYwnRJAzxuCRzauhMZ6kb5bWV-j_QFlaoeeNl2RX0avlzuJq437wb1ujZ8B9exNmV97hnCP2YKUZFr4By3-bna1qGBwRYfxYAu_-0u57Ini5bX4BnLMU81Cl578Jd2yuOGvRXi0X3lPju42TgFoMx9M=DF1B4E12");

	}
}
