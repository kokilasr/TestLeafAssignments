package week3AssignmentJIRAChaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateJiraTask extends BaseClass {
	@Test

	public void NewIncident()
	{

		input=RestAssured.given()
				.contentType("application/json")
				.when().body("{\r\n"
						+ "    \"fields\": {\r\n"
						+ "        \"project\": {\r\n"
						+ "            \"key\": \"RKS\"\r\n"
						+ "        },\r\n"
						+ "        \"summary\": \"create issue in RA project\",\r\n"
						+ "        \"description\": \"Creating of an issue using project keys and issue type names using the REST API\",\r\n"
						+ "        \"issuetype\": {\r\n"
						+ "            \"name\": \"Task\"\r\n"
						+ "        }\r\n"
						+ "    }\r\n"
						+ "}");

		response = input.post();
		System.out.println(response.getStatusCode());
		key = response.jsonPath().get("key");
		System.out.println("Taks id is: " + key);
		response.prettyPrint();
	}
}
