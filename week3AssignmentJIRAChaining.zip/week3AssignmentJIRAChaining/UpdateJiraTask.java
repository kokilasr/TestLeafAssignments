package week3AssignmentJIRAChaining;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateJiraTask extends BaseClass {

	@Test(dependsOnMethods = "week3AssignmentJIRAChaining.CreateJiraTask.NewIncident")
	public void updateJira() {

		input = RestAssured.given().contentType("application/json").body("{\r\n"
				+ "    \"fields\": {\r\n"
				+ "\r\n"
				+ "        \"description\": \"Bug creation Using REST API for testing\"\r\n"
				+ "    }\r\n"
				+ "}");
		response = input.put("/"+ key);
		response.then().assertThat().statusCode(Matchers.equalTo(204));
		response.prettyPrint();
	}
}
