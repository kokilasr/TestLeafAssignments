package week3AssignmentJIRAChaining;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class DeleteJiraTaskTask extends BaseClass {

	@Test(dependsOnMethods = "week3AssignmentJIRAChaining.UpdateJiraTask.updateJira")

	public void deleteJira() {
		response = RestAssured.delete("/"+ key);
		response.then().assertThat().statusCode(Matchers.equalTo(204));
		

	}
}
