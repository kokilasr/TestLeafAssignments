package stepDefinitionJira;

import java.io.File;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class JiraSteps {
	public static RequestSpecification input;
	public static Response response;
	public static String key;

	@Given("Set the Endpoint")
	public void setEndPoint() {
		RestAssured.baseURI="https://kokilajira.atlassian.net/rest/api/2/issue";
	}

	@And("Set the Auth")
	public void authentication() {
		RestAssured.authentication= RestAssured.preemptive().basic("kokila.shree@gmail.com","ATATT3xFfGF0E9tJabu2qrkomuU_e9n4mYwnRJAzxuCRzauhMZ6kb5bWV-j_QFlaoeeNl2RX0avlzuJq437wb1ujZ8B9exNmV97hnCP2YKUZFr4By3-bna1qGBwRYfxYAu_-0u57Ini5bX4BnLMU81Cl578Jd2yuOGvRXi0X3lPju42TgFoMx9M=DF1B4E12");
	}

	@When("Create JIRA task {string}")
	public void createJiraTask(String filename)
	{
		File createFile = new File("./src/main/resources/" + filename);
		input=RestAssured.given()
				.contentType("application/json")
				.body(createFile);
		response = input.post();
		System.out.println("The status code is:" + response.getStatusCode());
		key = response.jsonPath().get("key");
		System.out.println("Task key is: " + key);
		response.prettyPrint();
	}

	@Then("validate status code as {int}")
	public void validateResponseCode(int statusCode)
	{
		response.then().assertThat().statusCode(statusCode);
	}
	
	@When("Update Jira task {string}")
	public void updateJiraTask(String updateFile)
	{
		File file = new File("./src/main/resources/"+updateFile);
		input = RestAssured.given().contentType("application/json").body(file);
		response = input.put("/" + key);
		System.out.println("Task id is: " + key);
		System.out.println("The status code is:" + response.getStatusCode());

	}
	
	@When("delete Jira task")
	public void deleteJiraTask() {
		System.out.println("Taks id is: " + key);
		response = RestAssured.delete("/"+key);
		System.out.println("The status code is:" + response.getStatusCode());
	}
}
